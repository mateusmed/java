package com.mateusmed.architecturestudy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArchitecturestudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArchitecturestudyApplication.class, args);
	}

}
